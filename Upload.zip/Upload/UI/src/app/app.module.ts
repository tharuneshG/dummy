import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { HomedashComponent } from './homedash/homedash.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { MentorsearchComponent } from './mentorsearch/mentorsearch.component';
import { MentorhomeComponent } from './mentorhome/mentorhome.component';
import { MentornavComponent } from './mentornav/mentornav.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentornotificationComponent } from './mentornotification/mentornotification.component';
import { MentorpaymentComponent } from './mentorpayment/mentorpayment.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UsernavComponent } from './usernav/usernav.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UserproposedComponent } from './userproposed/userproposed.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminnavComponent } from './adminnav/adminnav.component';
import { AdminblockComponent } from './adminblock/adminblock.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';
import { AdminpayreceiveComponent } from './adminpayreceive/adminpayreceive.component';
import { AdmintechComponent } from './admintech/admintech.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ApiService } from './service/api.service';
import { TokenInterceptor } from './core/interceptor';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    HomedashComponent,
    LoginComponent,
    SignupComponent,
    MentorsignupComponent,
    MentorsearchComponent,
    MentorhomeComponent,
    MentornavComponent,
    MentorprogressComponent,
    MentornotificationComponent,
    MentorpaymentComponent,
    UserhomeComponent,
    UsernavComponent,
    UserdashComponent,
    UserproposedComponent,
    AdminhomeComponent,
    AdminnavComponent,
    AdminblockComponent,
    AdminpaymentComponent,
    AdminpayreceiveComponent,
    AdmintechComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule,
    HttpClientModule
   
  ],
  providers: [ApiService,{provide: HTTP_INTERCEPTORS,
  useClass: TokenInterceptor,
  multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
