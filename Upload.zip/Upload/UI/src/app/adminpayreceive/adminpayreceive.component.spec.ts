import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminpayreceiveComponent } from './adminpayreceive.component';

describe('AdminpayreceiveComponent', () => {
  let component: AdminpayreceiveComponent;
  let fixture: ComponentFixture<AdminpayreceiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminpayreceiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminpayreceiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
