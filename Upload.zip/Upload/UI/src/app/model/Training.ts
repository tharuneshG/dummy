import { Time } from '@angular/common';

export class Training{
    tid:number;
    mid:number;
    sid:number;
    status:number;
    progress:number;
    rating:number;
    start_time:Time;
    end_time:Time;
    start_date:Date;
    end_date:Date;
    amount_received:number;
    fees:number;
    user_name:string;
    mentor_name:string;
    skill_name:string;
}