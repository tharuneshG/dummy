import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HomedashComponent } from './homedash/homedash.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { MentorsearchComponent } from './mentorsearch/mentorsearch.component';
import { MentorhomeComponent } from './mentorhome/mentorhome.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';
import { MentornotificationComponent } from './mentornotification/mentornotification.component';
import { MentorpaymentComponent } from './mentorpayment/mentorpayment.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UserproposedComponent } from './userproposed/userproposed.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminblockComponent } from './adminblock/adminblock.component';
import { AdminpaymentComponent } from './adminpayment/adminpayment.component';
import { AdminpayreceiveComponent } from './adminpayreceive/adminpayreceive.component';
import { AdmintechComponent } from './admintech/admintech.component';


const routes: Routes = [
  {
    path:'',redirectTo:'home',pathMatch:'full'
  },
  {
    path:'home',component:HomeComponent,
    children:[
      {
        path:'',redirectTo:'homedash',pathMatch:'full'
      },
      {
        path:'homedash',component:HomedashComponent
      },
      {
        path:'login',component:LoginComponent
      },
      {
        path:'signup',component:SignupComponent
      },
      {
        path:'mentorsignup',component:MentorsignupComponent
      },
      {
        path:'mentorsearch',component:MentorsearchComponent
      }
     
    ]
  },

  {
    path:'homementor', component: MentorhomeComponent,
    children:[
      {
        path:'',redirectTo:'mentorprogress',pathMatch:'full'
      },
      {
        path:'mentorprogress',component:MentorprogressComponent
      },
      {
        path:'mentorsearch',component:MentorsearchComponent
      },
      {
        path:'mentornotification',component:MentornotificationComponent
      },
      {
        path:'mentorpayment',component:MentorpaymentComponent
      }
      
    ]
  },
  {
    path:'userhome', component: UserhomeComponent,
    children:[
      {
        path:'',redirectTo:'userdash',pathMatch:'full'
      },
      {
        path:'userdash',component:UserdashComponent
      },
      {
        path:'mentorsearch',component:MentorsearchComponent
      },
      {
        path:'userproposed',component:UserproposedComponent
      }
      
    ]
  },
  {
    path:'adminhome', component: AdminhomeComponent,
    children:[
      {
        path:'',redirectTo:'adminblock',pathMatch:'full'
      },
      {
        path:'adminblock',component:AdminblockComponent
      },
      {
        path:'adminpayment',component:AdminpaymentComponent
      },
      {
        path:'adminpayreceive',component:AdminpayreceiveComponent
      },
      {
        path:'admintech',component:AdmintechComponent
      }
      
    ]
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
